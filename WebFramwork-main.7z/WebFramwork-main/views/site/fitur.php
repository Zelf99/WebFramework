<h1>fitur YII</h1>
<table class="table table-bordered">
	<tr>
		<td>Fast</td>
		<td>Yii give tou the maximum fuctionality by adding the least possible overhead</td>
	</tr>

	<tr>
		<td>Secure</td>
		<td>Sane default and built-in tools helps you solid and secure code</td>
	</tr>

	<tr>
		<td>Efficent</td>
		<td>Write more code in less time with simple, yet powerfull APIs and code genereation</td>
	</tr>
</table>